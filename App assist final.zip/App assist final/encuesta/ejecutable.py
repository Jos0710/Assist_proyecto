from PyQt5 import QtWidgets, uic

app = QtWidgets.QApplication([])

iniciar_sesion =  uic.loadUi("ingresar.ui")
registrarse = uic.loadUi("registrar.ui")
pregunta_1 = uic.loadUi("Pregunta_1.ui")
pregunta_2 = uic.loadUi("Pregunta_2.ui")
pregunta_3 = uic.loadUi("Pregunta_3.ui")
pregunta_4 = uic.loadUi("Pregunta_4.ui")
pregunta_5 = uic.loadUi("Pregunta_5.ui")
pregunta_6 = uic.loadUi("Pregunta_6.ui")
pregunta_7 = uic.loadUi("Pregunta_7.ui")
pregunta_8 = uic.loadUi("Pregunta_8.ui")
resultados = uic.loadUi("Resultados.ui")

def registrar():
    registrarse.hide()
    iniciar_sesion.show()

def acceder():
    iniciar_sesion.hide()
    pregunta_1.show()

def pasar_preg():
    pregunta_1.hide()
    pregunta_2.show()

def pasar_preg_2():
    pregunta_2.hide()
    pregunta_3.show()

def pasar_preg_3():
    pregunta_3.hide()
    pregunta_4.show()

def pasar_preg_4():
    pregunta_4.hide()
    pregunta_5.show()

def pasar_preg_5():
    pregunta_5.hide()
    pregunta_6.show()

def pasar_preg_6():
    pregunta_6.hide()
    pregunta_7.show()

def pasar_preg_7():
    pregunta_7.hide()
    pregunta_8.show()

def resultado():
    pregunta_8.hide()
    resultados.show()

def salir():
    app.exec()

registrarse.pushButton_2.clicked.connect(registrar)
iniciar_sesion.pushButton.clicked.connect(acceder)
pregunta_1.pushButton_3.clicked.connect(pasar_preg)
pregunta_2.pushButton_3.clicked.connect(pasar_preg_2)
pregunta_3.pushButton_3.clicked.connect(pasar_preg_3)
pregunta_4.pushButton_3.clicked.connect(pasar_preg_4)
pregunta_5.pushButton_3.clicked.connect(pasar_preg_5)
pregunta_6.pushButton_3.clicked.connect(pasar_preg_6)
pregunta_7.pushButton_3.clicked.connect(pasar_preg_7)
pregunta_8.pushButton_3.clicked.connect(resultado)

registrarse.show()
app.exec()
