from PyQt5 import QtCore, QtGui, QtWidgets
import sys

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setMinimumSize(QtCore.QSize(800, 600))
        MainWindow.setMaximumSize(QtCore.QSize(800, 600))
        MainWindow.setStyleSheet("background-color: qlineargradient(spread:reflect, x1:1, y1:0.068, x2:1, y2:1, stop:0 rgba(240, 115, 0, 255), stop:1 rgba(255, 255, 255, 255));")
        
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(240, 50, 541, 81))
        self.label.setStyleSheet("font: 75 11pt \"Times New Roman\";")
        self.label.setObjectName("label")
        
        self.openGLWidget = QtWidgets.QOpenGLWidget(self.centralwidget)
        self.openGLWidget.setGeometry(QtCore.QRect(-320, 880, 300, 200))
        self.openGLWidget.setObjectName("openGLWidget")
        
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(0, 0, 231, 181))
        self.label_2.setStyleSheet("image: url(:/newPrefix/logo-usb-medellin (1).png);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(360, 550, 93, 28))
        self.pushButton_3.setStyleSheet("font: 8pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
        
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(10, 190, 781, 41))
        self.label_3.setStyleSheet("font: 75 9pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        
        self.checkBox = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox.setGeometry(QtCore.QRect(110, 310, 541, 20))
        self.checkBox.setObjectName("checkBox")
        
        self.checkBox_2 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_2.setGeometry(QtCore.QRect(110, 340, 541, 20))
        self.checkBox_2.setObjectName("checkBox_2")
        
        self.checkBox_3 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_3.setGeometry(QtCore.QRect(110, 400, 541, 20))
        self.checkBox_3.setObjectName("checkBox_3")
        
        self.checkBox_4 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_4.setGeometry(QtCore.QRect(110, 370, 541, 20))
        self.checkBox_4.setObjectName("checkBox_4")
        
        self.checkBox_5 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_5.setGeometry(QtCore.QRect(110, 520, 81, 20))
        self.checkBox_5.setObjectName("checkBox_5")
        
        self.checkBox_6 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_6.setGeometry(QtCore.QRect(110, 490, 541, 20))
        self.checkBox_6.setObjectName("checkBox_6")
        
        self.checkBox_7 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_7.setGeometry(QtCore.QRect(110, 460, 541, 20))
        self.checkBox_7.setObjectName("checkBox_7")
        
        self.checkBox_8 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_8.setGeometry(QtCore.QRect(110, 430, 541, 20))
        self.checkBox_8.setObjectName("checkBox_8")
        
        self.checkBox_9 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_9.setGeometry(QtCore.QRect(110, 280, 541, 20))
        self.checkBox_9.setObjectName("checkBox_9")
        
        self.checkBox_10 = QtWidgets.QCheckBox(self.centralwidget)
        self.checkBox_10.setGeometry(QtCore.QRect(110, 250, 541, 20))
        self.checkBox_10.setObjectName("checkBox_10")
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "        PRUEBA - ASSIST UNIVERSIDAD SAN BUENAVENTURA "))
        self.pushButton_3.setText(_translate("MainWindow", "Continuar"))
        self.label_3.setText(_translate("MainWindow", " A lo largo de su vida, ¿cual de las siguientes sustancias ha consumido alguna vez? (SOLO PARA USOS NO-MÉDICOS)"))
        self.checkBox.setText(_translate("MainWindow", "c.  Cannabis (marihuana, costo, hierba, hashish, etc.) "))
        self.checkBox_2.setText(_translate("MainWindow", "d.  Cocaína (coca, farlopa, crack, etc.) "))
        self.checkBox_3.setText(_translate("MainWindow", "f.  Inhalantes (colas, gasolina/nafta, pegamento, etc.) "))
        self.checkBox_4.setText(_translate("MainWindow", "e.  Anfetaminas u otro tipo de estimulantes (speed, éxtasis, píldoras adelgazantes, etc.) "))
        self.checkBox_5.setText(_translate("MainWindow", "j.  Otros  "))
        self.checkBox_6.setText(_translate("MainWindow", "i.  Opiáceos (heroína, metadona, codeína, morfina, dolantina/petidina, etc.) "))
        self.checkBox_7.setText(_translate("MainWindow", "h.  Alucinógenos (LSD, ácidos, ketamina, PCP, etc.) "))
        self.checkBox_8.setText(_translate("MainWindow", "g.  Tranquilizantes o pastillas para dormir "))
        self.checkBox_9.setText(_translate("MainWindow", "b.  Bebidas alcohólicas (cerveza, vino, licores, destilados, etc.) "))
        self.checkBox_10.setText(_translate("MainWindow", "a.  Tabaco (cigarrillos, cigarros habanos, tabaco de mascar, pipa, etc.) "))


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
