from PyQt5 import QtCore, QtGui, QtWidgets
import sys

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1050, 600)
        MainWindow.setMinimumSize(QtCore.QSize(1050, 600))
        MainWindow.setMaximumSize(QtCore.QSize(800, 600))
        MainWindow.setStyleSheet("background-color: qlineargradient(spread:reflect, x1:1, y1:0.068, x2:1, y2:1, stop:0 rgba(240, 115, 0, 255), stop:1 rgba(255, 255, 255, 255));")
       
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
       
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(240, 50, 541, 81))
        self.label.setStyleSheet("font: 75 11pt \"Times New Roman\";")
        self.label.setObjectName("label")
       
        self.openGLWidget = QtWidgets.QOpenGLWidget(self.centralwidget)
        self.openGLWidget.setGeometry(QtCore.QRect(-320, 880, 300, 200))
        self.openGLWidget.setObjectName("openGLWidget")
       
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(0, 0, 231, 181))
        self.label_2.setStyleSheet("image: url(:/newPrefix/logo-usb-medellin (1).png);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(470, 530, 93, 28))
        self.pushButton_3.setStyleSheet("font: 8pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
        
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(10, 230, 1021, 41))
        self.label_3.setStyleSheet("font: 75 9pt \"Arial\";")
        self.label_3.setObjectName("label_3")
        
        self.comboBox_2 = QtWidgets.QComboBox(self.centralwidget)
        self.comboBox_2.setGeometry(QtCore.QRect(340, 310, 361, 31))
        self.comboBox_2.setStyleSheet("font: 10pt \"Arial\";")
        self.comboBox_2.setObjectName("comboBox_2")
        self.comboBox_2.addItem("")
        self.comboBox_2.setItemText(0, "")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        self.comboBox_2.addItem("")
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "        PRUEBA - ASSIST UNIVERSIDAD SAN BUENAVENTURA "))
        self.pushButton_3.setText(_translate("MainWindow", "Continuar"))
        self.label_3.setText(_translate("MainWindow", "En los últimos tres meses, ¿con qué frecuencia dejó de hacer lo que se esperaba de usted habitualmente por el consumo de las sustancias seleccionadas?"))
        self.comboBox_2.setItemText(1, _translate("MainWindow", "Nunca "))
        self.comboBox_2.setItemText(2, _translate("MainWindow", "1 ó 2 veces "))
        self.comboBox_2.setItemText(3, _translate("MainWindow", "Cada mes "))
        self.comboBox_2.setItemText(4, _translate("MainWindow", "Cada semana"))
        self.comboBox_2.setItemText(5, _translate("MainWindow", "Alucinógenos"))
        self.comboBox_2.setItemText(6, _translate("MainWindow", "A diario o casi a diario"))


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
