from PyQt5 import QtCore, QtGui, QtWidgets
import sys

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setMinimumSize(QtCore.QSize(800, 600))
        MainWindow.setMaximumSize(QtCore.QSize(800, 600))
        MainWindow.setStyleSheet("background-color: qlineargradient(spread:reflect, x1:1, y1:0.068, x2:1, y2:1, stop:0 rgba(240, 115, 0, 255), stop:1 rgba(255, 255, 255, 255));")
        
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(240, 50, 541, 81))
        self.label.setStyleSheet("font: 75 11pt \"Times New Roman\";")
        self.label.setObjectName("label")
        
        self.openGLWidget = QtWidgets.QOpenGLWidget(self.centralwidget)
        self.openGLWidget.setGeometry(QtCore.QRect(-320, 880, 300, 200))
        self.openGLWidget.setObjectName("openGLWidget")
        
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(0, 0, 231, 181))
        self.label_2.setStyleSheet("image: url(:/newPrefix/logo-usb-medellin (1).png);image: url(:/newPrefix/logo-usb-medellin (1).png);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2"
                                   )
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(130, 250, 81, 51))
        self.label_3.setStyleSheet("font: 75 11pt \"Arial\";border -radius:8px;")
        self.label_3.setObjectName("label_3")
        
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(130, 340, 81, 51))
        self.label_4.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(130, 430, 111, 51))
        self.label_5.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_5.setObjectName("label_5")
        
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(280, 260, 431, 31))
        self.lineEdit.setStyleSheet("font: 12pt \"Arial\";\n")
        self.lineEdit.setObjectName("lineEdit")
        
        self.lineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(280, 350, 431, 31))
        self.lineEdit_2.setStyleSheet("font: 12pt \"Arial\";\n")
        self.lineEdit_2.setObjectName("lineEdit_2")
        
        self.lineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_3.setGeometry(QtCore.QRect(280, 440, 431, 31))
        self.lineEdit_3.setStyleSheet("font: 12pt \"Arial\";\n")
        self.lineEdit_3.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lineEdit_3.setObjectName("lineEdit_3")
        
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(400, 530, 93, 28))
        self.pushButton.setStyleSheet("font: 75 8pt \"Arial\";")
        self.pushButton.setObjectName("pushButton")
        
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(640, 530, 93, 28))
        self.pushButton_3.setStyleSheet("font: 8pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "        PRUEBA - ASSIST UNIVERSIDAD SAN BUENAVENTURA "))
        self.label_3.setText(_translate("MainWindow", " Código:"))
        self.label_4.setText(_translate("MainWindow", " Usuario:"))
        self.label_5.setText(_translate("MainWindow", " Contraseña:"))
        self.pushButton.setText(_translate("MainWindow", "Ingresar"))
        self.pushButton_3.setText(_translate("MainWindow", "Salir"))



if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
