from PyQt5 import QtCore, QtGui, QtWidgets
import sys

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1000, 800)
        MainWindow.setMinimumSize(QtCore.QSize(1000, 800))
        MainWindow.setMaximumSize(QtCore.QSize(1000, 800))
        MainWindow.setStyleSheet("background-color: qlineargradient(spread:reflect, x1:1, y1:0.068, x2:1, y2:1, stop:0 rgba(240, 115, 0, 255), stop:1 rgba(255, 255, 255, 255));")
        
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
       
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(240, 50, 541, 81))
        self.label.setStyleSheet("font: 75 11pt \"Times New Roman\";")
        self.label.setObjectName("label")
       
        self.openGLWidget = QtWidgets.QOpenGLWidget(self.centralwidget)
        self.openGLWidget.setGeometry(QtCore.QRect(-320, 880, 300, 200))
        self.openGLWidget.setObjectName("openGLWidget")
       
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(0, 0, 231, 181))
        self.label_2.setStyleSheet("image: url(:/newPrefix/logo-usb-medellin (1).png);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
       
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(100, 210, 111, 31))
        self.label_3.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_3.setObjectName("label_3")
       
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(280, 210, 581, 31))
        self.lineEdit.setStyleSheet("border -radius:14px;\n")
        self.lineEdit.setObjectName("lineEdit")
       
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(442, 737, 141, 31))
        self.pushButton_2.setStyleSheet("font: 8pt \"Arial\";")
        self.pushButton_2.setObjectName("pushButton_2")
       
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(822, 737, 111, 31))
        self.pushButton_3.setStyleSheet("font: 8pt \"Arial\";")
        self.pushButton_3.setObjectName("pushButton_3")
       
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(100, 260, 111, 31))
        self.label_4.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_4.setObjectName("label_4")
        
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(100, 420, 111, 31))
        self.label_5.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_5.setObjectName("label_5")
        
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(100, 310, 111, 31))
        self.label_6.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_6.setObjectName("label_6")
        
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(100, 360, 111, 31))
        self.label_7.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_7.setObjectName("label_7")
        
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(100, 480, 111, 31))
        self.label_8.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_8.setObjectName("label_8")
        
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(100, 540, 111, 31))
        self.label_9.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_9.setObjectName("label_9")
        
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(100, 600, 111, 31))
        self.label_10.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_10.setObjectName("label_10")
        
        self.label_11 = QtWidgets.QLabel(self.centralwidget)
        self.label_11.setGeometry(QtCore.QRect(60, 660, 191, 31))
        self.label_11.setStyleSheet("font: 75 11pt \"Arial\";")
        self.label_11.setObjectName("label_11")
        
        self.lineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(280, 540, 581, 31))
        self.lineEdit_2.setStyleSheet("border -radius:14px;")
        self.lineEdit_2.setObjectName("lineEdit_2")
        
        self.lineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_3.setGeometry(QtCore.QRect(280, 480, 581, 31))
        self.lineEdit_3.setStyleSheet("border -radius:14px;")
        self.lineEdit_3.setObjectName("lineEdit_3")
        
        self.lineEdit_4 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_4.setGeometry(QtCore.QRect(280, 420, 581, 31))
        self.lineEdit_4.setStyleSheet("border -radius:14px;")
        self.lineEdit_4.setObjectName("lineEdit_4")
        
        self.lineEdit_5 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_5.setGeometry(QtCore.QRect(280, 360, 581, 31))
        self.lineEdit_5.setStyleSheet("border -radius:14px;")
        self.lineEdit_5.setObjectName("lineEdit_5")
        
        self.lineEdit_6 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_6.setGeometry(QtCore.QRect(280, 310, 581, 31))
        self.lineEdit_6.setStyleSheet("border -radius:14px;\n")
        self.lineEdit_6.setObjectName("lineEdit_6")
        
        self.lineEdit_7 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_7.setGeometry(QtCore.QRect(280, 260, 581, 31))
        self.lineEdit_7.setStyleSheet("border -radius:14px;")
        self.lineEdit_7.setObjectName("lineEdit_7")
        
        self.lineEdit_8 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_8.setGeometry(QtCore.QRect(280, 660, 581, 31))
        self.lineEdit_8.setStyleSheet("border -radius:14px;")
        self.lineEdit_8.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lineEdit_8.setObjectName("lineEdit_8")
        
        self.lineEdit_9 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_9.setGeometry(QtCore.QRect(280, 600, 581, 31))
        self.lineEdit_9.setStyleSheet("border -radius:14px;")
        
        self.lineEdit_9.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lineEdit_9.setObjectName("lineEdit_9")
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "        PRUEBA - ASSIST UNIVERSIDAD SAN BUENAVENTURA "))
        self.label_3.setText(_translate("MainWindow", " Nombre:"))
        self.pushButton_2.setText(_translate("MainWindow", "Registrase"))
        self.pushButton_3.setText(_translate("MainWindow", "Salir"))
        self.label_4.setText(_translate("MainWindow", " Edad:"))
        self.label_5.setText(_translate("MainWindow", " Barrio:"))
        self.label_6.setText(_translate("MainWindow", " Genero:"))
        self.label_7.setText(_translate("MainWindow", " Ocupación:"))
        self.label_8.setText(_translate("MainWindow", " Estracto:"))
        self.label_9.setText(_translate("MainWindow", " Usuario:"))
        self.label_10.setText(_translate("MainWindow", " Contraseña:"))
        self.label_11.setText(_translate("MainWindow", " Confirmar contraseña:"))


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
